#!/usr/bin/env python3

'''
This module contains the GCN class, which is a subclass of torch.nn.Module.
It is a simple Graph Convolutional Network model that consists of two GCNConv layers.
The first layer takes the node features as input and outputs 16 features.
The second layer takes these 16 features as input and outputs the final output.
'''

from torch_geometric.nn import GCNConv
import torch.nn.functional as F
import torch

class GCN(torch.nn.Module):
    '''
    The GCN class is a subclass of torch.nn.Module.
    It is a simple Graph Convolutional Network model 
    that consists of two GCNConv layers. 
    The first layer takes the node features as 
    input and outputs 16 features. 
    The second layer takes these 16 features as 
    input and outputs the final output.
    '''
    def __init__(self, dataset):
        '''
        The constructor initializes the two GCNConv layers.

        Parameters:
            PyG Dataset: The dataset object.

        Returns:
            None
        '''
        super().__init__()
        self.conv1 = GCNConv(dataset.num_node_features, 16)
        self.conv2 = GCNConv(16, dataset.num_classes)

    def forward(self, data):
        '''
        The forward method takes a single argument,
        data, which is a PyG Data object.
        It first extracts the node features and edge
        indices from the data object.
        It then applies the first GCNConv layer followed
        by a ReLU activation function.
        Finally, it applies the second GCNConv layer
        and returns the output.
        
        Parameters:
            PyG Data: The input data object.

        Returns:
            Tensor: The output tensor of the model.
        '''
        x, edge_index = data.x, data.edge_index

        x = self.conv1(x, edge_index)
        x = F.relu(x)
        output = self.conv2(x, edge_index)

        return output

    def __str__(self):
        return self.__class__.__name__
