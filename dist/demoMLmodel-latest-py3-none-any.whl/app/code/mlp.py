#!/usr/bin/env python3

'''
This module contains the MLP class, which is a subclass of torch.nn.Module.
It is a simple Multi-Layer Perceptron model that consists of three linear layers.
The first layer takes the node features as input and outputs 64 features.
The second layer takes these 64 features as input and outputs 32 features.
The final layer takes these 32 features as input and outputs the final output.
'''

from torch import nn

class MLP(nn.Module):
    '''
    The MLP class is a subclass of torch.nn.Module.
    It is a simple Multi-Layer Perceptron model that
    consists of three linear layers.
    The first layer takes the node features as input
    and outputs 64 features.
    The second layer takes these 64 features as input
    and outputs 32 features.
    The final layer takes these 32 features as input
    and outputs the final output.
    '''
    def __init__(self, dataset):
        '''
        The constructor initializes the three linear layers.

        Parameters:
            PyG Dataset: The dataset object.

        Returns:
            None
        '''
        super().__init__()
        self.layers = nn.Sequential(
        nn.Linear(dataset.num_node_features, 64),
        nn.ReLU(),
        nn.Linear(64, 32),
        nn.ReLU(),
        nn.Linear(32, dataset.num_classes)
        )

    def forward(self, data):
        '''
        The forward method takes a single argument,
        data, which is a PyG Data object.
        It first extracts the node features from the
        data object.
        It then applies the three linear layers and
        returns the output.

        Parameters:
            PyG Data: The input data object.

        Returns:
            Tensor: The output tensor of the model.
        '''
        x = data.x  # only using node features (x)
        output = self.layers(x)
        return output

    def __str__(self):
        return self.__class__.__name__
